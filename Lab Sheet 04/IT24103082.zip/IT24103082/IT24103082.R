setwd("C:\\Users\\it24103082\\Desktop\\IT24103082")
getwd()


#Import the dataset
data<-read.table("DATA 4.txt",header=TRUE,sep="")

#view the files in separate window
fix(data)

attach(data)

#Part 02(a)
#Obtaining Box Plots
boxplot(X1,main="Box plot for Team Attendence",outline=TRUE,outpch=8,horizontal=TRUE)
boxplot(X2,main="Box plot for Team Salary",outline=TRUE,outpch=8,horizontal=TRUE)
boxplot(X3,main="Box plot for Team Years",outline=TRUE,outpch=8,horizontal=TRUE)


#Obtaining Histogram
hist(X1,ylab="Frequency",xlab="Team Attendence",main="Histogram for Team attendence")
hist(X2,ylab="Frequency",xlab="Team Salary",main="Histogram for Team Salary")
hist(X3,ylab="Frequency",xlab="Team Years",main="Histogram for Team Years")


#Stem ans Leaf Plot
stem(X1)
stem(X2)
stem(X3)

#Part 02(b)
#Mean
mean(X1)
mean(X2)
mean(X3)

#Median
median(X1)
median(X2)
median(X3)

#SD
sd(X1)
sd(X2)
sd(X3)

#Part 02(c)
#Five number summary
summary(X1)
summary(X2)
summary(X3)

#Getting only five number summary for X1 variable
quantile(X1)

#calling first quartile of X1 using index value
quantile(X1)[2]

#Calling third quartile of X1 using index value
quantile(X1)[4]

#Part 2(d)
IQR(X1)
IQR(X2)
IQR(X3)

#Part 03
#get the mode of a data set
get.mode<-function(y){
  counts<-table(X3)
  names(counts[counts==max(counts)])
  
}

#obtaining the mode of a variable
get.mode(X3)

#Get the frequency table for the variable
table(X3)

#Maximun frequency in the frequency table
max(counts)

counts[counts==max(counts)]

names(counts[counts==max(counts)])


#Part 04
#check the existence of outliers of a data set
get.outliers <- function(z){
  q1<-quantile(z)[2]
  q3<-quantile(z)[4]
  iqr<-q3-q1
  
  ub<-q3+1.5*iqr
  lb<-q1-1.5*iqr
  
  print(paste("Upper Bound= ",ub))
  print(paste("Lower Bound= ",lb))
  print(paste("outliers: ",paste(sort(z[z<lb|z>ub]),collapse=",")))
}

#checking the outliers of a variable 
get.outliers(X1)
get.outliers(X2)
get.outliers(X3)


#Calculate the interval for outliers
get.outliers<function(z){
  q1<-quantile(z)[2]
  q3<-quantile(z)[4]
  iqr<-q3
  
  ub<-q3+1.5*iqr
  lb<-q1-1.5*iqr
  
  #display the upper boundary and lower boundary of the interval
  print(paste("Upper Bound= ",ub))
  print(paste("Lower Bound= ",lb))
  
  
  #checking the existence of outliers and display the outliers is exist
  print(paste("outliers: ",paste(sort(z[x<lb|z>ub]),collapse=",")))
  
  
  
  
  #Exercise
  #1
  branch_data <- read.table("Exercise.txt", header = TRUE, sep=",")
  attach(branch_data)
  
  #2)
  #Types & scales:
  #Branch: identifier(nominal)
  #Scales_X1: quantitative, ratio
  #Advertising_X2: quantitative, ratio
  #Years_X3: quantitative discrete, ratio
  
  #Q3)
  boxplot(Sales_X1,
          main = "Box Plot for Sales",
          ylab = "Sales_X1",
          outline = TRUE,
          outpch = 8,
          horizontal = TRUE)
  
  #Q4)
  quantile(Advertising_X2)
  IQR(Advertising_X2)
  
  #Q5)
  get.outliers <- function(z){
    q1 <- quantile(z)[2]; q3 <- quantile(z)[4]; iqr <- q3 - q1
    ub <- q3 + 1.5*iqr; lb <- q1 - 1.5*iqr
    print(paste("Upper Bound = ",ub))
    print(paste("Lower Bound = ",lb))
    print(paste("Outliers:",paste(sort(z[z < lb | z > ub]), collapse = ", ")))
  }
  get.outliers(Years_X3)
  